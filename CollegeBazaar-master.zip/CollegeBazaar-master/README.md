# CollegeBazaar
Online Marketplace for College Students

Salient Features:

1. Special used items section
2. One-to-one seller and buyer matching
3. Secure transactions
